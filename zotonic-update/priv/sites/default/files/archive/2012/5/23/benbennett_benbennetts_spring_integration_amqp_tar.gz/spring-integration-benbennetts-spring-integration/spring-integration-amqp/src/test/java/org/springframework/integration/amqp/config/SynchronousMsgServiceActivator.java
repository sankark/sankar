/*
 * Copyright 2002-2010 the original author or authors.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package org.springframework.integration.amqp.config;
import org.springframework.integration.Message;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.message.GenericMessage;

import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Service;

import org.w3c.dom.Document;


import javax.annotation.Resource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import java.io.StringWriter;

/**
 * User: Benjamin Bennett 
 * Date: Nov 19, 2010
 * Time: 3:18:35 PM
 */
@MessageEndpoint
@Service("serviceY_SYSTEMFake")
public class SynchronousMsgServiceActivator {
	//Need to make sure messages are correspond to the correct request
    @ServiceActivator
    public Message<String> rx(GenericMessage<String>msg ){
		String mr = msg.getPayload();
	    Message<String> rt = MessageBuilder.withPayload(mr)
			    .copyHeaders(msg.getHeaders())
			    .setCorrelationId(msg.getHeaders().getId()).build();
		//don't really care about the host information.
		return rt;
    }

}
