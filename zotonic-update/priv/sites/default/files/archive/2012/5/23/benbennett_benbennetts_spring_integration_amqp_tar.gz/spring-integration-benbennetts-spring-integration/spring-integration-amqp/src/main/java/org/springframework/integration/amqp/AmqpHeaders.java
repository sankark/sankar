/*
 * Copyright 2002-2010 the original author or authors.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package org.springframework.integration.amqp;

import org.springframework.amqp.core.MessageProperties;
import org.springframework.util.Assert;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * User: Benjamin Bennett
 * Date: Dec 12, 2010
 * Time: 6:34:38 PM
 */
public abstract class AmqpHeaders {
	//not using prefix for now
	public static final String PREFIX = "";

	public static final String MESSAGE_ID = PREFIX + "messageId";

	public static final String CORRELATION_ID = PREFIX + "correlationId";

	public static final String REPLY_TO = PREFIX + "replyTo";

	public static final String [] KEYS= {MESSAGE_ID,CORRELATION_ID,REPLY_TO};

	private static Map<String, Method> methodMap=null;
	
	public static  Map<String, Method> getMethodMap(){
		if(methodMap==null){
			methodMap= new HashMap<String,Method>();
			Map <String,String>prefixMap = new HashMap<String,String>();
			for(String s : KEYS){
				prefixMap.put(s.replaceFirst(PREFIX,""),s);
			}
			for(Method m : MessageProperties.class.getDeclaredMethods()){
				if(m.getParameterTypes().length>0){
					continue;
				}
				String orig =m.getName();
				String get= "get";
				if(orig.startsWith(get) && !orig.startsWith("getHead")){
					String headerKey = orig.replace(get,"");
					String firstChar = headerKey.substring(0,1);
					headerKey = headerKey.replaceAll(firstChar,firstChar.toLowerCase());
					if(prefixMap.containsKey(headerKey)){
						methodMap.put(prefixMap.get(headerKey),m);
					}
				}
			}
		}
		return methodMap;
	}
}
