/*
 * $Id: q-noarg1.sql,v 1.1 2007/08/09 03:28:37 unsaved Exp $
 *
 * Simplest test of \q with no args
 */

\p Just quitting.  Should exit with 0 (success) exit status.
\q
