/*
 * Copyright 2002-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.integration.amqp.config;

import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.integration.config.xml.AbstractOutboundChannelAdapterParser;
import org.springframework.integration.config.xml.IntegrationNamespaceUtils;

/**
 * Parser for the AMQP 'outbound-channel-adapter' element.
 *
 * @author Mark Fisher
 * @since 2.0
 */
public class AmqpOutboundChannelAdapterParser extends AbstractOutboundChannelAdapterParser {
	static final String EXCHANGE_NAME = "exchange-name";
	static final String ROUTING_KEY = "routing-key";
	static final String ROUTE_REF = "route-ref";
	static final String BINDING_REF = "binding-ref";
	static final String REPLY_CHANNEL= "reply-channel";
	static final String MESSAGE_CONVERTER= "message-converter";
	@Override
	protected AbstractBeanDefinition parseConsumer(Element element, ParserContext parserContext) {
		BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(
				"org.springframework.integration.amqp.AmqpOutboundEndpoint");
		builder.addConstructorArgReference(element.getAttribute("amqp-template"));
		boolean hasExAndRouteKey = StringUtils.hasText(element.getAttribute(EXCHANGE_NAME))
				&& StringUtils.hasText(element.getAttribute(ROUTING_KEY));
		boolean hasRouteRef = StringUtils.hasText(element.getAttribute(ROUTE_REF));
		boolean hasBindingRef = StringUtils.hasText(element.getAttribute(BINDING_REF));
		Assert.isTrue(hasExAndRouteKey ^ hasRouteRef ^ hasBindingRef);
		IntegrationNamespaceUtils.setValueIfAttributeDefined(builder, element, EXCHANGE_NAME);
		IntegrationNamespaceUtils.setValueIfAttributeDefined(builder, element, ROUTING_KEY);
		IntegrationNamespaceUtils.setReferenceIfAttributeDefined(builder, element, ROUTE_REF);
		IntegrationNamespaceUtils.setReferenceIfAttributeDefined(builder, element, BINDING_REF);
		IntegrationNamespaceUtils.setReferenceIfAttributeDefined(builder, element, REPLY_CHANNEL);
		IntegrationNamespaceUtils.setReferenceIfAttributeDefined(builder, element,MESSAGE_CONVERTER );
		return builder.getBeanDefinition();
	}

}
