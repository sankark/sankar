/*
 * Copyright 2002-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.integration.amqp.config;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import junit.framework.TestCase;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.rabbit.connection.SingleConnectionFactory;
import org.springframework.amqp.rabbit.core.ChannelCallback;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.rabbitmq.client.Channel;

import javax.annotation.Resource;

/**
 * @author Mark Fisher
 * @since 2.0
 */
@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class EchoSample extends TestCase {
	@Resource(name = "rxMsgServ")
	private EchoServiceActivator rxMsgs;
	@Resource(name = "rb.inbound")
	private Binding inBoundRbConfig;

	@BeforeClass
	public static void setup() {

	}

	@Test
	public void sendToRabbit() throws Exception {
		int NUM_MSGS = 1000;
		try {
			String hostName = "localhost";
			int portNumber = AMQP.PROTOCOL.PORT;
			String exchange = inBoundRbConfig.getExchangeName();
			String routingKey = inBoundRbConfig.getRoutingKey();

			ConnectionFactory cfconn = new ConnectionFactory();
			cfconn.setHost(hostName);
			cfconn.setPort(portNumber);
			Connection conn = cfconn.newConnection();

			Channel ch = conn.createChannel();

			for (int i = 0; i < NUM_MSGS; i++) {
				String message = "Msg :" + Integer.toString(i);
				ch.basicPublish(exchange, routingKey, null, message.getBytes());
			}
			ch.close();
			conn.close();
		} catch (Exception e) {
			System.err.println("Main thread caught exception: " + e);
			e.printStackTrace();
			System.exit(1);
		}
		//wait a little bit to see if it caught up.
		Thread.sleep(60000);
		assertTrue("Rx Msgs : " + Integer.toString(this.rxMsgs.getRxMsgs().size()) + " Tx Msgs:" + Integer.toString(NUM_MSGS * 2), this.rxMsgs.getRxMsgs().size() == NUM_MSGS * 2);
	}

}
