/*
 * Copyright 2002-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.integration.amqp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.*;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.integration.Message;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.handler.AbstractReplyProducingMessageHandler;
import org.springframework.util.Assert;

import java.util.Map;

/**
 * Adapter that converts and sends Messages to an AMQP Exchange.
 * 
 * @author Mark Fisher
 * @since 2.0
 */
public class AmqpOutboundEndpoint extends AbstractReplyProducingMessageHandler {

	private final AmqpTemplate amqpTemplate;

	private volatile String exchangeName = "";

	private volatile String routingKey = "";

	private MessageConverter messageConverter = new SimpleMessageConverter();

	private static Logger log = LoggerFactory.getLogger(AmqpOutboundEndpoint.class);
	/**
	 * Contructor requires an AmqpTemplate  
	 *
	 */
	public AmqpOutboundEndpoint(AmqpTemplate amqpTemplate) {
		Assert.notNull(amqpTemplate, "AmqpTemplate must not be null");
		this.amqpTemplate = amqpTemplate;
	}
	/**
	 * Specify a reference to a AMQP binding.
	 *
	 */
	public void setBindingRef(Binding binding) {
		setRouteRef(binding);
	}
	/**
	 * Specify a reference to a route element. 
	 */
	public void setRouteRef(Route route) {
		this.exchangeName = route.getExchangeName();
		this.routingKey = route.getRoutingKeyString();
	}
	/**
	 * Required Specify the AMQP exchange name.  
	 */
	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}
	
	/**
	 * Required Specify the AMQP routing key.  
	 */
	public void setRoutingKey(String routingKey) {
		this.routingKey = routingKey;
	}

	/**
	 * Required Specify the AMQP routing key.
	 */
	public void setMessageConverter(MessageConverter messageConverter) {
		this.messageConverter = messageConverter;
	}
	/**
	 * Specify the Spring Integration reply channel. If this property is not
	 * set the gateway will check for a 'replyChannel' header on the request.
	 * TODO USAGE OF METHOD
	 */
	public void setReplyChannel(MessageChannel replyChannel) {
		this.setOutputChannel(replyChannel);
	}


	@Override
	protected Object handleRequestMessage(Message<?> requestMessage) {
		// TODO: add conditional logic for expectReply
		MessagePostProcessor messagePostProcessor = new AmqpMessagePostProcessor(requestMessage);
		Object mr = null;
		String ex = this.exchangeName;
		String rtKey = this.routingKey;
		if(requestMessage.getHeaders().getReplyChannel()!=null){
			log.debug("synchronous message call to amqp");
			 return this.amqpTemplate.convertSendAndReceive(ex, rtKey, requestMessage.getPayload(),messagePostProcessor,messageConverter);
		}
		//TODO map back headers. 
		if(requestMessage.getHeaders().get(AmqpHeaders.REPLY_TO)!=null){
			log.debug("synchronous message with REPLY_TO , sending message back to origin ");
			Address address = new Address((String)requestMessage.getHeaders().get(AmqpHeaders.REPLY_TO));
			ex = address.getExchangeName();
			rtKey = address.getRoutingKey();
		}
		log.debug("asynchronous call sending out to amqp");
		this.amqpTemplate.convertAndSend(ex,rtKey, requestMessage.getPayload(),messagePostProcessor,messageConverter);
		return null;
	}
	//TODO Class stub for future. 
	private static class AmqpMessagePostProcessor implements MessagePostProcessor {

		private final Message<?> integrationMessage;

		private AmqpMessagePostProcessor(Message<?> integrationMessage){
			this.integrationMessage = integrationMessage;
		}
		public org.springframework.amqp.core.Message postProcessMessage(org.springframework.amqp.core.Message amqpMessage) throws AmqpException {

			if(integrationMessage.getHeaders()!=null){
				for(Map.Entry<String,Object> kvp : integrationMessage.getHeaders().entrySet() ){
					if(kvp.getKey().startsWith("amqp") && kvp.getValue()!=null){
						amqpMessage.getMessageProperties().setHeader(kvp.getKey(),kvp.getValue().toString());	
					}

				}
			}
			amqpMessage.getMessageProperties().setMessageId(integrationMessage.getHeaders().getId().toString());

			return amqpMessage;
		}
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof AmqpOutboundEndpoint)) return false;

		AmqpOutboundEndpoint that = (AmqpOutboundEndpoint) o;

		if (amqpTemplate != null ? !amqpTemplate.equals(that.amqpTemplate) : that.amqpTemplate != null) return false;
		if (exchangeName != null ? !exchangeName.equals(that.exchangeName) : that.exchangeName != null) return false;
		if (routingKey != null ? !routingKey.equals(that.routingKey) : that.routingKey != null) return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = (exchangeName != null ? exchangeName.hashCode() : 0);
		result = 31 * result + (routingKey != null ? routingKey.hashCode() : 0);
		return result;
	}
}
