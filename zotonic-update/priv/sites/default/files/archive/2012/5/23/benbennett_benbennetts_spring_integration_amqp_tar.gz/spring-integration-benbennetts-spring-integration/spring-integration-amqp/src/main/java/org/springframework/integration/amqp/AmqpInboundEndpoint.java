/*
 * Copyright 2002-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.integration.amqp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.integration.endpoint.MessageProducerSupport;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.util.Assert;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Adapter that receives Messages from an AMQP Queue, converts them into
 * Spring Integration Messages, and sends the results to a Message Channel.
 * 
 * @author Mark Fisher
 * @since 2.0
 */
public class AmqpInboundEndpoint extends MessageProducerSupport {

	private final SimpleMessageListenerContainer messageListenerContainer;

	private MessageConverter messageConverter = new SimpleMessageConverter();

	private static Logger log = LoggerFactory.getLogger(AmqpInboundEndpoint.class);
	public AmqpInboundEndpoint(ConnectionFactory connectionFactory) {
		Assert.notNull(connectionFactory, "ConnectionFactory must not be null");
		this.messageListenerContainer = new SimpleMessageListenerContainer(connectionFactory);
		this.messageListenerContainer.setAutoStartup(false);
	}
	private String [] getSingleQueue(String queue){
		String [] names = {queue};
		return names;
	}
	public AmqpInboundEndpoint(ConnectionFactory connectionFactory, Queue queue) {
		Assert.notNull(connectionFactory, "ConnectionFactory must not be null");
		this.messageListenerContainer = new SimpleMessageListenerContainer(connectionFactory);
		this.messageListenerContainer.setAutoStartup(false);
		this.messageListenerContainer.setQueueNames(getSingleQueue(queue.getName()));
	}

	public void setQueueRef(Queue queue) {
		this.messageListenerContainer.setQueueNames(getSingleQueue(queue.getName()));
	}

	public void setQueueName(String queueName) {
		this.messageListenerContainer.setQueueNames(getSingleQueue(queueName));
	}
	public void setMessageConverter(MessageConverter messageConverter){
		this.messageConverter = messageConverter;
	}
	private Map<String,Object> getAmqpHeaders(MessageProperties messageProperties){
		Map<String,Object> mrHeaders = new HashMap<String,Object>();
		for(Map.Entry<String, Method>method : AmqpHeaders.getMethodMap().entrySet() ){
			try{
				Object mr = method.getValue().invoke(messageProperties,null);
				if(null!=mr){
					mrHeaders.put(method.getKey(),mr.toString());
				}
			}
			catch(Exception e){
				log.warn("could not convert "+method.getKey());
			}
		}
		return mrHeaders;
	}
	@Override
	protected void onInit() {
		this.messageListenerContainer.setMessageListener(new MessageListener() {
			@Override
			public void onMessage(Message message) {
				if(log.isDebugEnabled()){
					log.debug("message recieved "+message.getMessageProperties().getMessageId());
				}
				Object payload = messageConverter.fromMessage(message);
				org.springframework.integration.Message  msg = null;
				msg = MessageBuilder.withPayload(payload)
						.copyHeaders(getAmqpHeaders(message.getMessageProperties()))
						.copyHeaders(message.getMessageProperties().getHeaders())
						.build();
				log.debug("sending to spring integration ");
				sendMessage(msg);
			}
		});
		this.messageListenerContainer.afterPropertiesSet();
		super.onInit();
	}

	@Override
	protected void doStart() {
		this.messageListenerContainer.start();
	}

	@Override
	protected void doStop() {
		this.messageListenerContainer.stop();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof AmqpInboundEndpoint)) return false;

		AmqpInboundEndpoint that = (AmqpInboundEndpoint) o;
		if(!messageListenerContainer.getConnectionFactory().equals(
				that.messageListenerContainer.getConnectionFactory())){
			return false;
		}
		int i=0;
		for(String qN :messageListenerContainer.getQueueNames()){
			if(that.messageListenerContainer.getQueueNames().length==i){
				return false;
			}
			String other = that.messageListenerContainer.getQueueNames()[i];
			if(!qN.equals(other)){
				return false;
			}
			i++;
		}

		return true;
	}

	@Override
	public int hashCode() {
		int result = 31;
		for(String qN: messageListenerContainer.getQueueNames()){
			result+=qN.hashCode();
		}
		return result;
	}
}
