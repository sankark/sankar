/*
 * Copyright 2002-2010 the original author or authors.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package org.springframework.integration.amqp.config;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.Route;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.message.GenericMessage;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.integration.Message;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.Random;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class SynchronousMsgTest extends TestCase {
	@Resource(name = "rxGetMsgXRoute")
	private Route inBoundRbConfig;
	@Resource(name = "synchronousGatewayX_SYSTEM")
	private SynchronousGateWay syncGateway;
	@Resource(name = "X_SYSTEM_txGetMsgX")
	private MessageChannel txGetSiChannel;
	//simulate another system doing requests
	public static String N = "noise";
	public static String R = "real";
    public static GenericMessage<String> noiseMsg = new GenericMessage<String>(N);
	public static boolean done;
	public static synchronized boolean isDone(boolean isDone){
		if(isDone!=SynchronousMsgTest.done)
			SynchronousMsgTest.done = isDone;
		return SynchronousMsgTest.done;
	}
	@Test
	public void testSynchronousMsg() throws Exception {
		done=false;
		Random sleepRand = new Random(12343);
		Thread noisyThread = new NoiseMaker(inBoundRbConfig,txGetSiChannel);
		noisyThread.start();
		for(int i=0; i<50000;i++){
			String msgNum = R+Integer.toString(i);
		    Message msg = new GenericMessage<String>(msgNum);
			try{
				Message mr = syncGateway.getReply(msg);
				Assert.notNull(mr);
				Assert.notNull(mr.getPayload());
				Assert.notNull(mr.getPayload().toString().equals(msgNum));
				System.out.println("got reply");
			}catch (Exception e){
				System.out.println("Failure woops");
			}
		}
		isDone(true);
	}
	public class NoiseMaker extends Thread{
		private Route rt;
		private MessageChannel txGetSiChannel;
		public NoiseMaker(Route r_in,MessageChannel messageChannel){
			rt=r_in;
			this.txGetSiChannel = messageChannel;
		}
		public void run(){
			Random sleepRand = new Random(12343);
			try {
				while(!isDone(false)){
					Message hold = noiseMsg;
					//this.txGetSiChannel.send(hold);
					Thread.sleep(100+(sleepRand.nextInt()%100));
				}
			} catch (Exception e) {
				System.err.println("Main thread caught exception: " + e);
				e.printStackTrace();
			}
		}
	}

}
